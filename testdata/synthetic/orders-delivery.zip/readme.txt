Your data request. Each folder holds one category as CSV. Fictional delivery for the regression suite.
