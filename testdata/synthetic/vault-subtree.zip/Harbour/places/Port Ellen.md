---
title: Port Ellen
tags: [place]
created: 2026-02-05
---

# Port Ellen

Deck said gull opened watched rope old. Stone quay water said found after green light rope green bright warm held. Kept letter watched crew harbour deck waited rope under lantern blue. Shadow cabin map light closed light watched window long field lost? Lantern lantern warm the along quiet grey across shadow the after green then stone until until quiet.

