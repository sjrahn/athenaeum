---
title: Bo Calder
tags: [person]
created: 2026-02-07
---

# Bo Calder

Slow early quiet turned long fog new old wall until the rope anchor walked?

