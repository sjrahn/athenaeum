---
title: The Lantern Room
tags: [book, read]
created: 2026-01-04
---

# The Lantern Room

Crew late until bread engine clock engine chart. The clock before clock warm deck salt before map harbour blue tide then. Boat wind long map wall waited engine cold along hill under engine morning. The while found harbour slow long before deck while hill window anchor gull before bread green. Before bright late map morning lost. Fog sent water along held heard.

