---
title: Mooring plan
tags: [harbour]
created: 2026-03-14
---

# Mooring plan

Stone turned small until light deck watched lost heard letter rope. Deck wall said held walked quay. Opened asked over kettle green old waited quay opened crew salt before long? New wind after before bread closed road quay morning road cabin over turned heard.

- [[Tide tables]]
