Download share of a fictional vendor, assembled for the regression suite.
