This archive holds the personal data you requested, one CSV per category.
Fictional export for the regression suite.
